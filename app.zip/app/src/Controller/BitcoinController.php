<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class BitcoinController extends AbstractController
{
    private $client;

    public function __construct(HttpClientInterface $client)
    {
        $this->client = $client;
    }

    #[Route('/', name: 'bitcoin')]
    public function index() : Response
    {
        $apiUrl = $_ENV['API_URL'];
        $response = $this->client->request('GET', $apiUrl);
        $data = json_decode($response->getContent(), true);

        return $this->render('bitcoin/index.html.twig', [
            'data' => $data,
        ]);
    }
}
